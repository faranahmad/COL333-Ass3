#!/bin/bash
python plananalyze.py $1 > $1.out
