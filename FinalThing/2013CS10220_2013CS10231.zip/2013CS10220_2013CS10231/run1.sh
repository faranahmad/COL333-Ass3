#!/bin/bash
python pddlgen2.py $1 < $1.txt