#!/bin/bash
python plananalyze.py > $1.out
