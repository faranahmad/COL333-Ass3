#!/bin/bash
python pddlgen2.py < $1.txt